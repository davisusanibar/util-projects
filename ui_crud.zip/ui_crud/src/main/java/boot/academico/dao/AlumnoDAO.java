package boot.academico.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import boot.academico.model.Alumno;

public interface AlumnoDAO extends JpaRepository<Alumno, Integer> {

}
