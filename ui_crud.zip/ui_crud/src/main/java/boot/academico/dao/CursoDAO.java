package boot.academico.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import boot.academico.model.Curso;

public interface CursoDAO extends JpaRepository<Curso, Integer> {

}
