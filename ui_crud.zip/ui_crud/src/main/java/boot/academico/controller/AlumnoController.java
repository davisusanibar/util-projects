package boot.academico.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import boot.academico.dao.AlumnoDAO;
import boot.academico.model.Alumno;

@Controller
@RequestMapping("/academico/alumno")
public class AlumnoController {
	@Autowired
	AlumnoDAO alumnoDAO;	
	
	@RequestMapping(value="/listar")
	public String listaAlumno(Model model){
		model.addAttribute("listaAlumnos", alumnoDAO.findAll());
		return "academico/listado";
	}
	
	@RequestMapping(value="/irainsertar")
	public String insertarAlumno(Model model){
		model.addAttribute("alumno", new Alumno());
		return "academico/insertar";
	}	
	
	@RequestMapping(value="/guardar", method=RequestMethod.POST)	
	public String guardarAlumno(@ModelAttribute(value="alumno") Alumno alumno){						
		alumnoDAO.save(alumno);
						
		return "redirect:/academico/alumno/listar";
	}	
}
