package boot.academico.model;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;

import com.fasterxml.jackson.annotation.JsonManagedReference;

@Entity
public class Alumno {
	@Id
	@GeneratedValue
	@Column(name = "codigo_alumnito")
	private int codigo;	
	private String nombre;
	private int edad;
	
	@OneToMany(mappedBy = "codigo_alumno", cascade=CascadeType.ALL)
	@JsonManagedReference
	private List<Curso> listaCursos;
	
	public Alumno() {
		super();
	}

	public Alumno(int codigo, String nombre, int edad, List<Curso> listaCursos) {
		super();
		this.codigo = codigo;
		this.nombre = nombre;
		this.edad = edad;
		this.listaCursos = listaCursos;
	}

	public int getCodigo() {
		return codigo;
	}

	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public int getEdad() {
		return edad;
	}

	public void setEdad(int edad) {
		this.edad = edad;
	}

	public List<Curso> getListaCursos() {
		return listaCursos;
	}

	public void setListaCursos(List<Curso> listaCursos) {
		this.listaCursos = listaCursos;
	}
}
