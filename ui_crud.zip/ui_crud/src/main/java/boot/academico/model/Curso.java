package boot.academico.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import com.fasterxml.jackson.annotation.JsonBackReference;

@Entity
public class Curso {
	@Id
	@GeneratedValue
	private int codigo;
	private String nombre;
	
	@ManyToOne
	@JoinColumn(name="codigo_alumnito")
	@JsonBackReference
	private Alumno codigo_alumno;

	public Curso() {
		super();
	}

	public Curso(int codigo, String nombre, Alumno codigo_alumno) {
		super();
		this.codigo = codigo;
		this.nombre = nombre;
		this.codigo_alumno = codigo_alumno;
	}

	public int getCodigo() {
		return codigo;
	}

	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public Alumno getCodigo_alumno() {
		return codigo_alumno;
	}

	public void setCodigo_alumno(Alumno codigo_alumno) {
		this.codigo_alumno = codigo_alumno;
	}
	
	
}
